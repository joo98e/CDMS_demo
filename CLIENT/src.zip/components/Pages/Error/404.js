import React, { Component } from 'react'
import { connect } from 'react-redux'

export class Error_404 extends Component {
    render() {
        return (
            <div>
                Error_404
            </div>
        )
    }
}

const mapStateToProps = (state) => ({
    
})

const mapDispatchToProps = {
    
}

export default connect(mapStateToProps, mapDispatchToProps)(Error_404)