// ────────────────────────────────────────────────── UI
export const SET_THEME = "SET_THEME";
export const SET_MENU_APPEAR_POSITION = "SET_MENU_APPEAR_POSITION";
export const SET_PATH_GUIDER = "SET_PATH_GUIDER";

// ─────────────────────────────────────────────────── Auth
export const GET_AUTHENTICATED = "GET_AUTHENTICATED";
export const OUT_AUTHENTICATED = "OUT_AUTHENTICATED";
export const DEV_SET_AUTH = "DEV_SET_AUTH";

// ─────────────────────────────────────────────────── Produce
export const SET_REGISTER_MEMBER_INFO = "SET_REGISTER_MEMBER_INFO";
export const SET_PROJECT_PERSON_LIST = "SET_PROJECT_PERSON_LIST";
export const SET_PROJECT_PERSON_LIST_INIT = "SET_PROJECT_PERSON_LIST_INIT";
export const SET_REGISTER_MEMBER_INFO_INIT = "SET_REGISTER_MEMBER_INFO_INIT";
export const SET_AGENCY_INFO = "SET_AGENCY_INFO";
export const SET_AGENCY_INFO_INIT = "SET_AGENCY_INFO_INIT";
export const SET_PROJECT_INFO = "SET_PROJECT_INFO";
export const SET_PROJECT_INFO_INIT = "SET_PROJECT_INFO_INIT";
