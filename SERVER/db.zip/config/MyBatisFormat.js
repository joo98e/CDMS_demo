const format = { language: 'sql', indent: '  ' };

module.exports = format;