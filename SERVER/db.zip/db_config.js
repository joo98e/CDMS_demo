module.exports = (() => {
    return {
        "host": "beok.dscloud.me",
        "port": "3307",
        "user": "myboard",
        "password": "EVERYbeok1!2#",
        "database": "CDMS"
    }
})(); 

